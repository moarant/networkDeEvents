// Generic JS settings used on all Admin pages of the plugin

jQuery(document).ready(function($) {


});